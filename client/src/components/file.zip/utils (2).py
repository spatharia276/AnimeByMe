import bpy, sys, linecache, ast, os
import math
from math import *
from mathutils import *
from bpy.types import Panel, UIList


# Versions compatibility ---------------------------------------------------------------------------------------
class ARP_blender_version:
    _string = bpy.app.version_string
    blender_v = bpy.app.version
    _float = blender_v[0]*100+blender_v[1]+blender_v[2]*0.01
    _char = bpy.app.version_char

blender_version = ARP_blender_version()


def check_id_root(action):
    bl_version = blender_version._float
    if bl_version >= 291:
        if getattr(action, "id_root", None) == "OBJECT":
            return True
        else:
            return False
    else:
        return True


def invert_angle_with_blender_versions(angle=None, bone=False, axis=None):
    # Deprecated when rotating bones, use rotate_edit_bone() instead
    # bpy.ops.transform.rotate has inverted angle value depending on the Blender version
    # this function is necessary to support these version specificities
    bl_version = blender_version._float

    #print("BL VERSION", bl_version)
    invert = False
    if bone == False:
        if (bl_version >= 283 and bl_version < 290) or (bl_version >= 291 and bl_version < 292):
            invert = True

    elif bone == True:
        # bone rotation support
        # the rotation direction is inverted in Blender 2.83 only for Z axis
        if axis == "Z":
            if bl_version >= 283 and bl_version < 290:
                invert = True
        # the rotation direction is inverted for all but Z axis in Blender 2.90 and higher
        if axis != "Z":
            if bl_version >= 290:
                invert = True

    if invert:
        angle = -angle

    return angle


# Context mode ---------------------------------------------------------------------------------------------------
def get_current_mode():
    return bpy.context.mode


def restore_current_mode(current_mode):
    if current_mode == 'EDIT_ARMATURE':
        current_mode = 'EDIT'
    if current_mode == "EDIT_MESH":
        current_mode = "EDIT"
    bpy.ops.object.mode_set(mode=current_mode)


# Keyframes, animation ---------------------------------------------------------------------------------------------------
def bake_anim(frame_start=0, frame_end=10, only_selected=False, bake_bones=True, bake_object=False, shape_keys=False, _self=None, action_export_name=None, new_action=True):
    # similar to bpy.ops.nla.bake but faster
    # warning: "new_action" set to False overwrites the current action, only works with bones having no existing keyframes, only constraints

    scn = bpy.context.scene
    obj_data = []
    bones_data = []
    armature = bpy.data.objects.get(bpy.context.active_object.name)

    def get_bones_matrix():
        matrices_dict = {}
        for pbone in armature.pose.bones:
            if only_selected and not pbone.bone.select:
                continue
            matrices_dict[pbone.name] = armature.convert_space(pose_bone=pbone, matrix=pbone.matrix, from_space="POSE", to_space="LOCAL")
        return matrices_dict

    def get_obj_matrix():
        parent = armature.parent
        matrix = armature.matrix_world
        if parent:
            return parent.matrix_world.inverted_safe() @ matrix
        else:
            return matrix.copy()

    # make list of meshes with valid shape keys
    sk_objects = []
    if shape_keys and _self and action_export_name:# bake shape keys value for animation export
        for ob_name in _self.char_objects:
            ob = bpy.data.objects.get(ob_name+"_arpexport")
            if ob.type != "MESH":
                continue
            if ob.data.shape_keys == None:
                continue
            if len(ob.data.shape_keys.key_blocks) <= 1:
                continue
            sk_objects.append(ob)

    # store matrices
    current_frame = scn.frame_current
    for f in range(int(frame_start), int(frame_end+1)):
        scn.frame_set(f)
        bpy.context.view_layer.update()
        """
        # trigger the update two times to fix instability with IK Splines curves as proxy
        bpy.context.evaluated_depsgraph_get().update()
        scn.frame_set(f)
        bpy.context.view_layer.update()
        """
        # bones data
        if bake_bones:
            bones_data.append((f, get_bones_matrix()))

        # objects data
        if bake_object:
            obj_data.append((f, get_obj_matrix()))

        # shape keys data (for animation export only)
        for ob in sk_objects:
            for i, sk in enumerate(ob.data.shape_keys.key_blocks):
                if (sk.name == "Basis" or sk.name == "00_Basis") and i == 0:
                    continue
                #print(sk.name, float(f-int(frame_range[0])), sk.value)
                frame_in_action = float(f-int(frame_start))
                dict_entry = action_export_name+'|'+'BMesh#'+ob.data.name+'|Shape|BShape Key#'+sk.name+'|'+str(frame_in_action)
                #print(dict_entry, sk.value)
                _self.shape_keys_data[dict_entry] = sk.value

        print_progress_bar("Baking phase 1", f-frame_start, frame_end-frame_start)

    print("")

    # set new action
    action = None
    if new_action:
        action = bpy.data.actions.new("Action")
        anim_data = armature.animation_data_create()
        anim_data.action = action
    else:
        action = armature.animation_data.action

    def store_keyframe(bone_name, prop_type, fc_array_index, frame, value):
        fc_data_path = 'pose.bones["' + bone_name + '"].' + prop_type
        fc_key = (fc_data_path, fc_array_index)
        if not keyframes.get(fc_key):
            keyframes[fc_key] = []
        keyframes[fc_key].extend((frame, value))


    # set transforms and store keyframes
    if bake_bones:
        bone_count = 0
        total_bone_count = len(armature.pose.bones)

        for pbone in armature.pose.bones:
            bone_count += 1
            print_progress_bar("Baking phase 2", bone_count, total_bone_count)

            if only_selected and not pbone.bone.select:
                continue

            euler_prev = None
            quat_prev = None
            keyframes = {}

            for (f, matrix) in bones_data:
                pbone.matrix_basis = matrix[pbone.name].copy()

                for arr_idx, value in enumerate(pbone.location):
                    store_keyframe(pbone.name, "location", arr_idx, f, value)

                rotation_mode = pbone.rotation_mode
                if rotation_mode == 'QUATERNION':
                    if quat_prev is not None:
                        quat = pbone.rotation_quaternion.copy()
                        if blender_version._float >= 282:# previous versions don't know this function
                            quat.make_compatible(quat_prev)
                        pbone.rotation_quaternion = quat
                        quat_prev = quat
                        del quat
                    else:
                        quat_prev = pbone.rotation_quaternion.copy()

                    for arr_idx, value in enumerate(pbone.rotation_quaternion):
                        store_keyframe(pbone.name, "rotation_quaternion", arr_idx, f, value)

                elif rotation_mode == 'AXIS_ANGLE':
                    for arr_idx, value in enumerate(pbone.rotation_axis_angle):
                        store_keyframe(pbone.name, "rotation_axis_angle", arr_idx, f, value)

                else:  # euler, XYZ, ZXY etc
                    if euler_prev is not None:
                        euler = pbone.rotation_euler.copy()
                        euler.make_compatible(euler_prev)
                        pbone.rotation_euler = euler
                        euler_prev = euler
                        del euler
                    else:
                        euler_prev = pbone.rotation_euler.copy()

                    for arr_idx, value in enumerate(pbone.rotation_euler):
                        store_keyframe(pbone.name, "rotation_euler", arr_idx, f, value)

                for arr_idx, value in enumerate(pbone.scale):
                    store_keyframe(pbone.name, "scale", arr_idx, f, value)

            # Add keyframes
            fi = 0
            for fc_key, key_values in keyframes.items():
                data_path, index = fc_key
                fcurve = action.fcurves.find(data_path=data_path, index=index)
                if new_action == False and fcurve:# for now always remove existing keyframes if overwriting current action, must be driven by constraints only
                    action.fcurves.remove(fcurve)
                    fcurve = action.fcurves.new(data_path, index=index, action_group=pbone.name)
                if fcurve == None:
                    fcurve = action.fcurves.new(data_path, index=index, action_group=pbone.name)

                num_keys = len(key_values) // 2
                fcurve.keyframe_points.add(num_keys)
                fcurve.keyframe_points.foreach_set('co', key_values)
                if blender_version._float >= 290:# internal error when doing so with Blender 2.83, only for Blender 2.90 and higher
                    linear_enum_value = bpy.types.Keyframe.bl_rna.properties['interpolation'].enum_items['LINEAR'].value
                    fcurve.keyframe_points.foreach_set('interpolation', (linear_enum_value,) * num_keys)
                else:
                    for kf in fcurve.keyframe_points:
                        kf.interpolation = 'LINEAR'


    if bake_object:
        euler_prev = None
        quat_prev = None

        for (f, matrix) in obj_data:
            name = "Action Bake"
            armature.matrix_basis = matrix

            armature.keyframe_insert("location", index=-1, frame=f, group=name)

            rotation_mode = armature.rotation_mode
            if rotation_mode == 'QUATERNION':
                if quat_prev is not None:
                    quat = armature.rotation_quaternion.copy()
                    if blender_version._float >= 282:# previous versions don't know this function
                        quat.make_compatible(quat_prev)
                    armature.rotation_quaternion = quat
                    quat_prev = quat
                    del quat
                else:
                    quat_prev = armature.rotation_quaternion.copy()
                armature.keyframe_insert("rotation_quaternion", index=-1, frame=f, group=name)
            elif rotation_mode == 'AXIS_ANGLE':
                armature.keyframe_insert("rotation_axis_angle", index=-1, frame=f, group=name)
            else:  # euler, XYZ, ZXY etc
                if euler_prev is not None:
                    euler = armature.rotation_euler.copy()
                    euler.make_compatible(euler_prev)
                    armature.rotation_euler = euler
                    euler_prev = euler
                    del euler
                else:
                    euler_prev = armature.rotation_euler.copy()
                armature.keyframe_insert("rotation_euler", index=-1, frame=f, group=name)

            armature.keyframe_insert("scale", index=-1, frame=f, group=name)


    # restore current frame
    scn.frame_set(current_frame)

    print("")


def clear_fcurve(fcurve):
    found = True
    while found:
        try:
            fcurve.keyframe_points.remove(fcurve.keyframe_points[0])
        except:
            found = False


def get_keyf_data(key):
    # return keyframe point data
    return [key.co[0], key.co[1], key.handle_left[0], key.handle_left[1], key.handle_right[0], key.handle_right[1],
            key.handle_left_type, key.handle_right_type, key.easing]


def set_keyf_data(key, data):
    # set keyframe point from data (list)
    key.co[0] = data[0]
    key.co[1] = data[1]
    key.handle_left[0] = data[2]
    key.handle_left[1] = data[3]
    key.handle_right[0] = data[4]
    key.handle_right[1] = data[5]
    key.handle_left_type = data[6]
    key.handle_right_type = data[7]
    key.easing = data[8]


# Objects ------------------------------------------------------------------------------------------------------
def set_active_object(object_name):
    bpy.context.view_layer.objects.active = get_object(object_name)
    get_object(object_name).select_set(state=1)


def get_object(name, view_layer_change=False):
    ob = bpy.data.objects.get(name)
    if ob:
        if view_layer_change:
            found = False
            for v_o in bpy.context.view_layer.objects:
                if v_o == ob:
                    found = True
            if not found:# object not in view layer, add to the base collection
                bpy.context.collection.objects.link(ob)

    return ob


def delete_object(obj):
    bpy.data.objects.remove(obj, do_unlink=True)


def set_active_object(object_name):
     bpy.context.view_layer.objects.active = bpy.data.objects[object_name]
     bpy.data.objects[object_name].select_set(state=True)


def hide_object(obj_to_set):
    obj_to_set.hide_set(True)
    obj_to_set.hide_viewport = True


def hide_object_visual(obj_to_set):
    obj_to_set.hide_set(True)


def is_object_hidden(obj_to_get):
    try:
        if obj_to_get.hide_get() == False and obj_to_get.hide_viewport == False:
            return False
        else:
            return True
    except:# the object must be in another view layer, it can't be accessed
        return True


def unhide_object(obj_to_set):
    # we can only operate on the object if it's in the active view layer...
    try:
        obj_to_set.hide_set(False)
        obj_to_set.hide_viewport = False
    except:
        print("Could not reveal object:", obj_to_set.name)


def duplicate_object():
    try:
        bpy.ops.object.duplicate(linked=False, mode='TRANSLATION')
    except:
        bpy.ops.object.duplicate('TRANSLATION', False)


def delete_children(passed_node, type):
    if passed_node:
        if type == "OBJECT":
            parent_obj = passed_node
            children = []

            for obj in bpy.data.objects:
                if obj.parent:
                    if obj.parent == parent_obj:
                        children.append(obj)
                        for _obj in children:
                            for obj_1 in bpy.data.objects:
                                if obj_1.parent:
                                    if obj_1.parent == _obj:
                                        children.append(obj_1)

            meshes_data = []

            for child in children:
                # store the mesh data for removal afterward
                try:
                    if child.data:
                        if not child.data.name in meshes_data:
                            meshes_data.append(child.data.name)
                except:
                    continue

                bpy.data.objects.remove(child, do_unlink=True, do_id_user=True, do_ui_user=True)

            for data_name in meshes_data:
                current_mesh = bpy.data.meshes.get(data_name)
                if current_mesh:
                    bpy.data.meshes.remove(current_mesh, do_unlink=True, do_id_user=True, do_ui_user=True)

            bpy.data.objects.remove(passed_node, do_unlink=True)

        elif type == "EDIT_BONE":
            current_mode = bpy.context.mode

            bpy.ops.object.mode_set(mode='EDIT')

            if bpy.context.active_object.data.edit_bones.get(passed_node.name):

                # Save displayed layers
                _layers = [bpy.context.active_object.data.layers[i] for i in range(0, 32)]

                # Display all layers
                for i in range(0, 32):
                    bpy.context.active_object.data.layers[i] = True

                bpy.ops.armature.select_all(action='DESELECT')
                bpy.context.evaluated_depsgraph_get().update()
                bpy.context.active_object.data.edit_bones.active = get_edit_bone(passed_node.name)
                bpy.ops.armature.select_similar(type='CHILDREN')
                bpy.ops.armature.delete()

                for i in range(0, 32):
                    bpy.context.active_object.data.layers[i] = _layers[i]

            # restore saved mode
            restore_current_mode(current_mode)


def parent_objects(_obj_list, target):
    for obj in _obj_list:
        if obj.type == "MESH":
            #print("parenting", obj.name)
            obj_mat = obj.matrix_world.copy()
            obj.parent = target
            obj.matrix_world = obj_mat


# Mesh --------------------------------------------------------------------------------------------
def create_mesh_data(mesh_name, verts, edges, faces):
    # create an new mesh data given verts, edges and faces data
    new_mesh = bpy.data.meshes.new(name=mesh_name)
    new_mesh.from_pydata(verts, edges, faces)
    return new_mesh


def create_object_mesh(obj_name, verts, edges, faces):
    shape_mesh = create_mesh_data(obj_name, verts, edges, faces)
    # create object
    shape = bpy.data.objects.new(obj_name, shape_mesh)
    return shape



# Armature -----------------------------------------------------------------------------------------

def restore_armature_layers(layers_select):
    # restore the armature layers visibility
    for i in range(0, 32):
        bpy.context.active_object.data.layers[i] = layers_select[i]


def enable_all_armature_layers():
    # enable all layers
    # and return the list of each layer visibility
    _layers = bpy.context.active_object.data.layers
    layers_select = []
    for i in range(0, 32):
        layers_select.append(_layers[i])
    for i in range(0, 32):
        bpy.context.active_object.data.layers[i] = True

    return layers_select



# Bone ----------------------------------------------------------------------------------------------
def get_bone_base_name(bone_name):
    base_name = bone_name[:-2]# head.x > head
    if "_dupli_" in bone_name:
        base_name = bone_name[:-12]
    return base_name


def set_bone_layer(editbone, layer_idx, multi=False):
    editbone.layers[layer_idx] = True
    if multi:
        return
    for i, lay in enumerate(editbone.layers):
        if i != layer_idx:
            editbone.layers[i] = False


def get_bone_side(bone_name):
    side = ""
    if not "_dupli_" in bone_name:
        side = bone_name[-2:]
    else:
        side = bone_name[-12:]
    return side


def get_data_bone(bonename):
    return bpy.context.active_object.data.bones.get(bonename)


def duplicate(type=None):
    # runs the operator to duplicate the selected objects/bones
    if type == "EDIT_BONE":
        bpy.ops.armature.duplicate_move(ARMATURE_OT_duplicate={}, TRANSFORM_OT_translate={"value": (0.0, 0.0, 0.0), "constraint_axis": (False, False, False),"orient_type": 'LOCAL', "mirror": False, "use_proportional_edit": False, "snap": False, "remove_on_cancel": False, "release_confirm": False})
    elif type == "OBJECT":
        bpy.ops.object.duplicate(linked=False, mode='TRANSLATION')



# Edit Bone ---------------------------------------------------------------------------------------------------------
def get_selected_edit_bones():
    return bpy.context.selected_editable_bones


def get_edit_bone(name):
    return bpy.context.object.data.edit_bones.get(name)


def move_bone_to_bone(bone1, bone2):
    # move editbone bone1 to bone2 based on the head location
    vec_delta = bone2.head - bone1.head
    roll = bone1.roll
    bone1.head += vec_delta
    bone1.tail += vec_delta
    bone1.roll = roll# restore roll


def move_bone(bone, value, axis):
    get_edit_bone(bone).head[axis] += value / bpy.context.scene.unit_settings.scale_length
    get_edit_bone(bone).tail[axis] += value / bpy.context.scene.unit_settings.scale_length


def copy_bone_rotation(bone1, bone2):
    # copy editbone bone1 rotation to bone2
    bone1_vec = bone1.tail-bone1.head
    bone2_length = (bone2.tail-bone2.head).magnitude
    bone2.tail = bone2.head + (bone1_vec.normalized() * bone2_length)
    bone2.roll = bone1.roll


def copy_bone_transforms(bone1, bone2):
    # copy editbone bone1 transforms to bone 2
    bone2.head = bone1.head.copy()
    bone2.tail = bone1.tail.copy()
    bone2.roll = bone1.roll


def copy_bone_transforms_mirror(bone1, bone2):
    bone01 = get_edit_bone(bone1 + ".l")
    bone02 = get_edit_bone(bone2 + ".l")

    bone02.head = bone01.head
    bone02.tail = bone01.tail
    bone02.roll = bone01.roll

    bone01 = get_edit_bone(bone1 + ".r")
    bone02 = get_edit_bone(bone2 + ".r")

    bone02.head = bone01.head
    bone02.tail = bone01.tail
    bone02.roll = bone01.roll


def rotate_edit_bone(edit_bone, angle_radian, axis):
    old_head = edit_bone.head.copy()
    # rotate
    R = Matrix.Rotation(angle_radian, 4, axis.normalized())
    edit_bone.transform(R, roll=True)
    # back to initial head pos
    offset_vec = -(edit_bone.head - old_head)
    new_x_axis = edit_bone.x_axis.copy()
    edit_bone.head += offset_vec
    edit_bone.tail += offset_vec
    # preserve roll
    align_bone_x_axis(edit_bone, new_x_axis)


def set_bone_layer(editbone, layer_idx, multi=False):
    editbone.layers[layer_idx] = True
    if multi:
        return
    for i, lay in enumerate(editbone.layers):
        if i != layer_idx:
            editbone.layers[i] = False


def create_edit_bone(bone_name, deform=False):
    b = get_edit_bone(bone_name)
    if b == None:
        b = bpy.context.active_object.data.edit_bones.new(bone_name)
        b.use_deform = deform
    return b


def select_edit_bone(name, mode=1):
    o = bpy.context.active_object
    ebone = get_edit_bone(name)

    if mode == 1:
        o.data.bones.active = o.pose.bones[name].bone
    elif mode == 2:
        o.data.edit_bones.active = o.data.edit_bones[name]
        o.data.edit_bones.active.select = True

    ebone.select_head = True
    ebone.select_tail = True
    ebone.select = True


def delete_edit_bone(editbone):
    bpy.context.active_object.data.edit_bones.remove(editbone)


# pose bone
def get_selected_pose_bones():
    return bpy.context.selected_pose_bones


def get_pose_bone(name):
    return bpy.context.active_object.pose.bones.get(name)


def set_bone_custom_shape(pbone, cs_name):
    cs = get_object(cs_name)
    if cs == None:
        append_cs(cs_name)
        cs = get_object(cs_name)

    pbone.custom_shape = cs


def set_bone_color_group(obj, pb, grp_name):
    grp_color_body_mid = (0.0, 1.0, 0.0)
    grp_color_body_left = (1.0, 0.0, 0.0)
    grp_color_body_right = (0.0, 0.0, 1.0)

    grp = obj.pose.bone_groups.get(grp_name)
    if grp == None:
        grp = obj.pose.bone_groups.new(name=grp_name)
        grp.color_set = 'CUSTOM'

        grp_color = None
        if grp_name == "body_mid":
            grp_color = grp_color_body_mid
        elif grp_name == "body_left":
            grp_color = grp_color_body_left
        elif grp_name == "body_right":
            grp_color = grp_color_body_right

        # set normal color
        grp.colors.normal = grp_color
        # set select color/active color
        for col_idx in range(0,3):
            grp.colors.select[col_idx] = grp_color[col_idx] + 0.2
            grp.colors.active[col_idx] = grp_color[col_idx] + 0.4

    pb.bone_group = grp


# Maths ----------------------------------------------------------------------------------------------------
def mat3_to_vec_roll(mat, ret_vec=False):
    vec = mat.col[1]
    vecmat = vec_roll_to_mat3(mat.col[1], 0)
    vecmatinv = vecmat.inverted()
    rollmat = vecmatinv @ mat
    roll = math.atan2(rollmat[0][2], rollmat[2][2])
    if ret_vec:
        return vec, roll
    else:
        return roll



def vec_roll_to_mat3(vec, roll):
    epsi = 0.0000000001
    target = Vector((0, 0.1, 0))
    nor = vec.normalized()
    axis = target.cross(nor)
    if axis.dot(axis) > epsi:
        axis.normalize()
        theta = target.angle(nor)
        bMatrix = Matrix.Rotation(theta, 3, axis)
    else:
        updown = 1 if target.dot(nor) > 0 else -1
        bMatrix = Matrix.Scale(updown, 3)
        bMatrix[2][2] = 1.0

    rMatrix = Matrix.Rotation(roll, 3, nor)
    mat = rMatrix @ bMatrix
    return mat


def align_bone_x_axis(edit_bone, new_x_axis):
    new_x_axis = new_x_axis.cross(edit_bone.y_axis)
    new_x_axis.normalize()
    dot = max(-1.0, min(1.0, edit_bone.z_axis.dot(new_x_axis)))
    angle = math.acos(dot)
    edit_bone.roll += angle
    dot1 = edit_bone.z_axis.dot(new_x_axis)
    edit_bone.roll -= angle * 2.0
    dot2 = edit_bone.z_axis.dot(new_x_axis)
    if dot1 > dot2:
        edit_bone.roll += angle * 2.0


def align_bone_z_axis(edit_bone, new_z_axis):
    new_z_axis = -(new_z_axis.cross(edit_bone.y_axis))
    new_z_axis.normalize()
    dot = max(-1.0, min(1.0, edit_bone.x_axis.dot(new_z_axis)))
    angle = math.acos(dot)
    edit_bone.roll += angle
    dot1 = edit_bone.x_axis.dot(new_z_axis)
    edit_bone.roll -= angle * 2.0
    dot2 = edit_bone.x_axis.dot(new_z_axis)
    if dot1 > dot2:
        edit_bone.roll += angle * 2.0


def signed_angle(vector_u, vector_v, normal):
    normal = normal.normalized()
    a = vector_u.angle(vector_v)
    if vector_u.cross(vector_v).angle(normal) < 1:
        a = -a
    return a


def project_point_onto_plane(q, p, n):
    # q = point
    # p = point belonging to the plane
    # n = plane normal
    n = n.normalized()
    return q - ((q - p).dot(n)) * n


def get_pole_angle(base_bone, ik_bone, pole_location):
    pole_normal = (ik_bone.tail - base_bone.head).cross(pole_location - base_bone.head)
    projected_pole_axis = pole_normal.cross(base_bone.tail - base_bone.head)
    return signed_angle(base_bone.x_axis, projected_pole_axis, base_bone.tail - base_bone.head)


def smooth_interpolate(value):
    # value: float belonging to [0, 1]
    # return the smooth interpolated value using cosinus function
    return (cos((value*pi + pi )) + 1) /2



def get_point_projection_onto_line_factor(a, b, p):
    # return the factor of the projected point 'p' onto the line 'a,b'
    # if below a, factor[0] < 0
    # if above b, factor[1] < 0
    return ((p - a).dot(b - a), (p - b).dot(b - a))


def project_point_onto_line(a, b, p):
    # project the point p onto the line a,b
    ap = p - a
    ab = b - a
    result = a + ap.dot(ab) / ab.dot(ab) * ab
    return result


def project_vector_onto_vector(a, b):
    abdot = (a[0] * b[0]) + (a[1] * b[1]) + (a[2] * b[2])
    blensq = (b[0] ** 2) + (b[1] ** 2) + (b[2] ** 2)

    temp = abdot / blensq
    c = Vector((b[0] * temp, b[1] * temp, b[2] * temp))

    return c


def cross(a, b):
    c = Vector((a[1]*b[2] - a[2]*b[1], a[2]*b[0] - a[0]*b[2], a[0]*b[1] - a[1]*b[0]))
    return c


def get_line_plane_intersection(planeNormal, planePoint, rayDirection, rayPoint, epsilon=1e-6):
    ndotu = planeNormal.dot(rayDirection)
    if abs(ndotu) < epsilon:
        raise RuntimeError("no intersection or line is within plane")

    w = rayPoint - planePoint
    si = -planeNormal.dot(w) / ndotu
    Psi = w + si @ rayDirection + planePoint
    return Psi

    
def rotate_object(obj, angle, axis, origin):
    # rotate the object around the "axis" (Vector) 
    # for the angle value (radians)
    # around the origin (Vector)
    rot_mat = Matrix.Rotation(angle, 4, axis.normalized())
    loc, rot, scale = obj.matrix_world.decompose()
    loc = loc - origin
    obj_mat = Matrix.Translation(loc) @ rot.to_matrix().to_4x4()
    obj_mat_rotated = rot_mat @ obj_mat
    loc, rot, scale = obj_mat_rotated.decompose()
    loc = loc + origin
    obj.location = loc.copy()
    obj.rotation_euler = rot.to_euler()
    
    # fix numerical imprecisions
    for i in range(0,3):
        rot = obj.rotation_euler[i]
        obj.rotation_euler[i] = round(rot, 4)
        

# Constraints -----------------------------------------------------------------------------------------------------
def set_constraint_inverse_matrix(cns):
    # set the inverse matrix of Child Of constraint
    subtarget_pbone = get_pose_bone(cns.subtarget)
    if subtarget_pbone:
        cns.inverse_matrix = subtarget_pbone.bone.matrix_local.to_4x4().inverted()


def add_copy_transf(p_bone, tar=None, subtar="", h_t=0.0, no_scale=False):
    if tar == None:
        tar = bpy.context.active_object

    if no_scale:
        cns1 = p_bone.constraints.new("COPY_LOCATION")
        cns1.name = "Copy Location"
        cns1.target = tar
        cns1.subtarget = subtar
        cns1.head_tail = h_t

        cns2 = p_bone.constraints.new("COPY_ROTATION")
        cns2.name = "Copy Rotation"
        cns2.target = tar
        cns2.subtarget = subtar

        return cns1, cns2
    else:
        cns1 = p_bone.constraints.new("COPY_TRANSFORMS")
        cns1.name = "Copy Transforms"
        cns1.target = tar
        cns1.subtarget = subtar
        cns1.head_tail=h_t

        return cns1, None


# Drivers --------------------------------------------------------------------------------------------------------
def add_driver_to_prop(obj, dr_dp, tar_dp, array_idx=-1, exp="var"):
    drivers_list = obj.animation_data.drivers
    dr = drivers_list.find(dr_dp)
    if dr == None:
        dr = obj.driver_add(dr_dp, array_idx)

    dr.driver.expression = exp

    var = dr.driver.variables.get('var')

    if var == None:
        var = dr.driver.variables.new()

    var.type = 'SINGLE_PROP'
    var.name = 'var'
    var.targets[0].id = obj
    var.targets[0].data_path = tar_dp


def create_custom_prop(bone=None, prop_name="", prop_val=1.0, prop_min=0.0, prop_max=1.0, prop_description="", soft_min=None, soft_max=None):
    if soft_min == None:
        soft_min = prop_min
    if soft_max == None:
        soft_max = prop_max

    if not "_RNA_UI" in bone.keys():
        bone["_RNA_UI"] = {}

    bone[prop_name] = prop_val
    bone["_RNA_UI"][prop_name] = {"use_soft_limits":True, "min": prop_min, "max": prop_max, "description": prop_description, "soft_min":soft_min, "soft_max":soft_max}
    bone.property_overridable_library_set('["'+prop_name+'"]', True)


def get_pbone_name_from_data_path(dp):
    # return the pbone name from the driver data path
    return dp.split('"')[1]


def replace_driver_target_object(dr, current_obj_name, new_obj_name):
    # replace the given driver target object as set in the variables, with a new one
    for var in dr.driver.variables:
        for tar in var.targets:
            if tar.id == get_object(current_obj_name):
                tar.id = get_object(new_obj_name)


def copy_driver_variables(variables, source_driver, suffix):
    for v1 in variables:
        # create a variable
        clone_var = source_driver.driver.variables.new()
        clone_var.name = v1.name
        clone_var.type = v1.type

        # copy variable path
        try:
            clone_var.targets[0].data_path = v1.targets[0].data_path
            # increment bone data path name
            if '.r"]' in v1.targets[0].data_path:
                new_d_path = v1.targets[0].data_path
                new_d_path = new_d_path.replace('.r"]', suffix + '"]')

            if '.l"]' in v1.targets[0].data_path:
                new_d_path = v1.targets[0].data_path
                new_d_path = new_d_path.replace('.l"]', suffix + '"]')

            clone_var.targets[0].data_path = new_d_path

        except:
            print("no data_path for: " + v1.name)

        try:
            clone_var.targets[0].bone_target = v1.targets[0].bone_target

            if ".r" in v1.targets[0].bone_target:
                clone_var.targets[0].bone_target = v1.targets[0].bone_target.replace(".r", suffix)
            if ".l" in v1.targets[0].bone_target:
                clone_var.targets[0].bone_target = v1.targets[0].bone_target.replace(".l", suffix)


        except:
            print("no bone_target for: " + v1.name)
        try:
            clone_var.targets[0].transform_type = v1.targets[0].transform_type
        except:
            print("no transform_type for: " + v1.name)
        try:
            clone_var.targets[0].transform_space = v1.targets[0].transform_space
        except:
            print("no transform_space for: " + v1.name)
        try:
            clone_var.targets[0].id_type = v1.targets[0].id_type
        except:
            print("no id_type for: " + v1.name)
        try:
            clone_var.targets[0].id = v1.targets[0].id
        except:
            print("no id for: " + v1.name)


def remove_duplicated_drivers():
    arm = bpy.context.active_object
    #print("-------", len(arm.animation_data.drivers), "drivers found")

    to_delete = []

    for i, dr in enumerate(arm.animation_data.drivers):
        found = False

        # find duplicates only if the current one is not already found
        for d in to_delete:
            if d[0] == dr.data_path and d[1] == dr.array_index:
                found = True
                break

        if not found:
            dp = dr.data_path
            array_idx = dr.array_index

            for j, dr1 in enumerate(arm.animation_data.drivers):
                if i != j:
                    if dp == dr1.data_path and array_idx == dr1.array_index:
                        to_delete.append([dp, array_idx])

    print("Found", len(to_delete), "duplicated drivers, delete them...")

    #print("Delete duplicated...")
    for dri in to_delete:
        try:
            arm.driver_remove(dri[0], dri[1])

        except:
            arm.driver_remove(dri[0], -1)

    #print(len(arm.animation_data.drivers), "drivers after deletion")


def remove_invalid_drivers():
    obj = bpy.context.active_object
    current_mode = bpy.context.mode
    bpy.ops.object.mode_set(mode='POSE')

    invalid_drivers_total = 0

    def is_driver_valid(dr, bone_name):
        if not dr.is_valid:
            return False
        if not obj.data.bones.get(bone_name):
            return False
        if "constraints" in dr.data_path:
            cns_name = dr.data_path.split('"')[3]
            target_bone = get_pose_bone(bone_name)
            found_cns = False

            if len(target_bone.constraints) > 0:
                for cns in target_bone.constraints:
                    if cns.name == cns_name:
                        found_cns = True
                if "cns" in locals():
                    del cns

            if not found_cns:
                return False

        return True

    for dr in obj.animation_data.drivers:
        if dr.data_path.startswith('pose.bones'):
            b = dr.data_path.split('"')[1]

            if not is_driver_valid(dr, b):
                # the driver is invalid
                # assign a dummy but valid data path since we can't remove drivers
                # with invalid data path
                # print("Invalid driver found:", dr.data_path)
                invalid_drivers_total += 1
                dr.array_index = 0
                dr.data_path = 'delta_scale'

    if 'dr' in locals():
        del dr

    #print("Found", invalid_drivers_total, "invalid drivers")

    count = 0
    for dr in obj.animation_data.drivers:
        if dr.data_path == "delta_scale":
            obj.animation_data.drivers.remove(dr)
            count += 1

    #print(count, "invalid drivers deleted")

    # restore saved mode
    restore_current_mode(current_mode)


# Collections ----------------------------------------------------------------------------------------------------------------------
def get_parent_collections(target):
    # return the list of all parent collections to the specified target collection
    # with a recursive function. A sub-function is used, string based, to ease the process

    def get_parent_collections_string(target_name):
        parent_collections = ""
        found = None

        for collec in bpy.data.collections:
            for child in collec.children:
                if child.name == target_name:
                    print("found", collec.name)
                    parent_collections += collec.name + ","
                    parent_collections += get_parent_collections_string(collec.name)

        return parent_collections


    string_result = get_parent_collections_string(target.name)
    to_list = [bpy.data.collections[i] for i in string_result[:-1].split(",") if i != ""]

    return to_list

    meshes_data = []

    for child in children:
        # store the mesh data for removal afterward
        if child.data:
            if not child.data.name in meshes_data:
                meshes_data.append(child.data.name)

        bpy.data.objects.remove(child, do_unlink=True, do_id_user=True, do_ui_user=True)

    for data_name in meshes_data:
        current_mesh = bpy.data.meshes.get(data_name)
        if current_mesh:
            bpy.data.meshes.remove(current_mesh, do_unlink=True, do_id_user=True, do_ui_user=True)


    bpy.data.objects.remove(passed_node, do_unlink = True)


def get_all_collections_list():
    def mt_traverse_tree(t):
        yield t
        for child in t.children:
            yield from mt_traverse_tree(child)

    colls = []
    coll = bpy.context.view_layer.layer_collection
    for c in mt_traverse_tree(coll):
        colls.append(c)
    return colls


def get_cs_collection():
    # returns the custom shape collection
    custom_shape_collection = None
    for col in bpy.data.collections:
        split_len = len(col.name.split('_'))
        if split_len > 0:
            if col.name.split('_')[split_len - 1] == "cs":
                custom_shape_collection = col
                break

    if custom_shape_collection == None:  # the collection haven't been found, the collection hierarchy isn't correct
        for collec in bpy.data.collections:  # look for any collection called cs_grp
            if collec.name.startswith("cs_grp"):
                custom_shape_collection = collec
                break

    return custom_shape_collection


def search_layer_collection(layerColl, collName):
    # Recursivly transverse layer_collection for a particular name
    found = None
    if (layerColl.name == collName):
        return layerColl
    for layer in layerColl.children:
        found = search_layer_collection(layer, collName)
        if found:
            return found


# Modifiers -------------------------------------------------------------------------------------------------------------------
def apply_modifier(mod_name):
    bl_version = blender_version._float
    if bl_version >= 290:
        bpy.ops.object.modifier_apply(modifier=mod_name)
    else:
        bpy.ops.object.modifier_apply(apply_as="DATA", modifier=mod_name)


# Print ---------------------------------------------------------------------------------------------------------------------
def print_progress_bar(job_title, progress, length):
    progress = int((progress * 100) / length)
    sys.stdout.write("\r  " + job_title + " %d%%" % progress)
    sys.stdout.flush()


# Types, conversion, values ------------------------------------------------------------------------------------------------------------------------
def vectorize3(list):
    return Vector((list[0], list[1], list[2]))


def vector_to_list(vector):
    return [i for i in vector]


def dict_to_string(dict):
    dict_str = {}
    for i in dict:
        dict_str[str(i)] = str(dict[i])
    return dict_str


def dict_to_int(dict):
    dict_int = {}
    for i in dict:
        dict_int[int(i)] = int(dict[i])
    return dict_int


def str_list_to_fl_list(list):
    new_list = []
    for i in list:
        new_list.append(float(i))
    return new_list


def vec_to_string(vec):
    string_var = str(vec[0])+','+str(vec[1])+','+str(vec[2])
    return string_var


def string_to_bool(string):
    if string.lower() == 'true':
        return True
    if string.lower() == 'false':
        return False


def clamp_max(value, max):
    if value > max:
        return max
    else:
        return value